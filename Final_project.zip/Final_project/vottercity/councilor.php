<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Untitled Document</title>
  <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../vottercity/bootstrap/css/bootstrap.min.css">
  <script src="../../vottercity/bootstrap/js/bootstrap.min.js"></script>

  <style>

 body {
 
font-family: Agency FB;
       }
</style>
</head>

<body>
<h2 align="center">Councilor Balotpaper</h2>
<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
session_start();
$id=$_SESSION['id'];
$sql="SELECT * FROM voterinfo WHERE Nid='$id'";
$result=mysqli_query($db,$sql);
while($row=mysqli_fetch_array($result))
{
$center= $row['Center'];
}
$sql="SELECT * FROM ward_list WHERE Center='$center'";
$result=mysqli_query($db,$sql);
while($row=mysqli_fetch_array($result))
{
$ward1=$row['Cityname'];
$ward=$row['Ward_No'];
}
$sql="SELECT * FROM  city_candidateinfo WHERE city='Rajshahi' and  Ward='$ward' and Ctype='councilor'" ;
$result=mysqli_query($db,$sql);
echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Name";echo"</td>"; 
echo "<th>"; echo "Photo";echo"</td>";
echo "<th>"; echo "Team";echo"</td>";
echo "<th>"; echo "Symbol";echo"</td>";
echo "<th>"; echo "vote";echo"</td>";
echo "</tr>";
while($row=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>".$row['Name']."</td>"; 
$ad=$row['Cphoto'];
echo "<td>";echo "<img style='float:center;border:3px solid black;border-radius:20px;width:100px;height:100px' src='".$ad."'>"; echo "</td>";
echo "<td>".$row['Team']."</td>";
$ad="../super/".$row['image'];
echo "<td>";echo "<img style='float:center;border:3px solid black;border-radius:20px;width:100px;height:100px' src='".$ad."'>"; echo "</td>";
echo '<form method="post" action="givevote2.php">
			<input type="hidden" name="Name1" value='.$row['Nid'].'>
			<input type="hidden" name="Team1" value='.$row['Team'].'>
			<input type="hidden" name="Seat1" value='.$row['city'].'>
			<input type="hidden" name="Ctype" value='.$row['Ctype'].'>
			<input type="hidden" name="cntr" value='.$center.'>
			<td><input type="submit" name="vote" Value="Vote"></td>';
echo "</form>";
echo "</tr>";
}
echo "</table>";



?>
</body>
</html>