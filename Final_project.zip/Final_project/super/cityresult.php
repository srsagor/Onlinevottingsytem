<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
<title>Untitled Document</title>
</head>

<body>
<h1 align="center" style="background-color:#00CCFF" style="border-bottom:hidden" style="width:100%">Election Commission Bangladesh</h1></td>
<div class="navbar">
 <a href="Sadminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="adminadd.php" style="text-decoration:none" style="display:block">Admin Add</a>
  <div class="dropdown">
    <button class="dropbtn">Candidate Add 
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="candidateadd.php" style="text-decoration:none" style="display:block">National election</a>
    <a href="cityelection.php" style="text-decoration:none" style="display:block">City election</a>
  </div>
</div>
<a href="teamadd.php" style="text-decoration:none" style="display:block">Team add </a>

<div class="dropdown">
    <button class="dropbtn">National Election
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="overallresult.php" style="text-decoration:none" style="display:block">Over all result </a>
	<a href="Seatresult.php" style="text-decoration:none" style="display:block">Winner List </a>
	<a href="allinfo.php" style="text-decoration:none" style="display:block">Final Result</a>
  </div>
</div>
<div class="dropdown">
    <button class="dropbtn">City Corporation Result
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="cityresult.php" style="text-decoration:none" style="display:block">City Corporation Result</a>
	<a href="citywinerlist.php" style="text-decoration:none" style="display:block">Winner List </a>
  </div>
</div>
<div class="dropdown">
    <button class="dropbtn">Election Update
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
   <a href="electionadd.php" style="text-decoration:none" style="display:block">Election Add</a>
	<a href="electiondlet.php" style="text-decoration:none" style="display:block">Election Delate</a>
  </div>
</div>
<a href="active.php" style="text-decoration:none" style="display:block">Active Election</a>
<a href="upload.php" style="text-decoration:none" style="display:block">Notice</a>
</div>
<form method="post">
<table align="center">
<tr>
<td><label>City Corporation Name:</label></td>
<td><select name="Seat" required>
     <option value="---------">Select One</option>
      <option value="Dhaka">Dhaka City </option>
	 <option value="Rajshahi">Rajshahi</option>
	 <option value="Khulna">Khulna</option>
	 <option value="Barisal">Barisal</option>
	 <option value="ctg">ctg</option>
	 <option value="Dinajpur-1">Dinajpur-1</option>
	 <option value="Dinajpur-2">Dinajpur-2</option>
	 <option value="Dinajpur-3">Dinajpur-3</option>
	 <option value="Dinajpur-4">Dinajpur-4</option>
	 <option value="Dinajpur-5">Dinajpur-5</option>
   </select>
</td>
</tr>
<tr>
<td><label>Candidate Type:</label></td>
<td><select name="type" required>
      <option value="Myeor">Myeor</option>
	 <option value="councilor">councilor</option>
	 <option value="Female_councilor">Female_councilor</option>
   </select>
</td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="Result"  /></td>
</tr>
</table>
</form>

<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$seat=mysqli_real_escape_string($db,$_POST['Seat']);
$type=mysqli_real_escape_string($db,$_POST['type']);
if(strcasecmp( $type, 'Myeor' ) == 0)
{
$result = mysqli_query($db,"SELECT SUM(Vote_Get) FROM city_candidateinfo WHERE city='$seat' and Ctype='$type'");
$row = mysqli_fetch_array($result);
$cast=$row['SUM(Vote_Get)'];
//echo $total;
$result = mysqli_query($db,"SELECT COUNT(*) FROM city_corporation WHERE city='$seat'");
$row = mysqli_fetch_array($result);
$total=$row['COUNT(*)'];
echo "</br>";
$prct=($cast/$total)*100;
$sql="SELECT * FROM city_candidateinfo WHERE city='$seat' and Ctype='$type'";
$result=mysqli_query($db,$sql);
echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Name";echo"</td>"; 
echo "<th>"; echo "Photo";echo"</td>";
echo "<th>"; echo "Team";echo"</td>";
echo "<th>"; echo "Candidate Type";echo"</td>";
echo "<th>"; echo "Vote Get";echo"</td>";
echo "</tr>";
while($row=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>".$row['Name']."</td>"; 
$ad=$row['Cphoto'];
             echo "<td>";echo "<img style='float:center;border:3px solid black;border-radius:20px;width:100px;height:100px' src='".$ad."'>"; echo "</td>";
echo "<td>".$row['Team']."</td>";
echo "<td>".$row['Ctype']."</td>";
echo "<td>".$row['Vote_Get']."</td>";
echo "</tr>";
}

echo "</table>";
echo "Percentage Of Vote cast:".$prct;


$result = mysqli_query($db,"SELECT MAX(Vote_Get) FROM city_candidateinfo WHERE city='$seat' and Ctype='$type' ");
$row = mysqli_fetch_array($result);
$vote=$row['MAX(Vote_Get)'];

$result = mysqli_query($db,"SELECT * FROM city_candidateinfo WHERE city='$seat' and Vote_Get='$vote' and Ctype='$type'");
$row = mysqli_fetch_array($result);
$a=$row['Name'];
$b=$row['Team'];
$c=$row['city'];
$d=$row['Nid'];
$e=$row['Ctype'];
$ad=$row['Cphoto'];
if($vote>0)
{
$result= mysqli_query($db,"INSERT INTO City_winner_list (Name,Team,City,Nid,Ctype,image)VALUES('$a','$b','$c','$d','$e','$ad')");
}
}




if(strcasecmp( $type, 'councilor' ) == 0)
{
$result = mysqli_query($db,"SELECT SUM(Vote_Get) FROM city_candidateinfo WHERE city='$seat' and Ctype='$type'");
$row = mysqli_fetch_array($result);
$cast=$row['SUM(Vote_Get)'];
//echo $total;
$result = mysqli_query($db,"SELECT COUNT(*) FROM city_corporation WHERE city='$seat'");
$row = mysqli_fetch_array($result);
$total=$row['COUNT(*)'];
echo "</br>";
$prct=($cast/$total)*100;

$sql="SELECT * FROM city_candidateinfo WHERE city='$seat' and Ctype='$type '";
$result=mysqli_query($db,$sql);
echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Name";echo"</td>"; 
echo "<th>"; echo "Ward";echo"</td>";
echo "<th>"; echo "Photo";echo"</td>";
echo "<th>"; echo "Team";echo"</td>";
echo "<th>"; echo "Candidate Type";echo"</td>";
echo "<th>"; echo "Vote Get";echo"</td>";
echo "</tr>";
while($row=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>".$row['Name']."</td>"; 
echo "<td>".$row['ward']."</td>"; 
$ad=$row['Cphoto'];
             echo "<td>";echo "<img style='float:center;border:3px solid black;border-radius:20px;width:100px;height:100px' src='".$ad."'>"; echo "</td>";
echo "<td>".$row['Team']."</td>";
echo "<td>".$row['Ctype']."</td>";
echo "<td>".$row['Vote_Get']."</td>";
echo "</tr>";
}

echo "</table>";
echo "Percentage Of Vote cast:".$prct;


      $result = mysqli_query($db,"SELECT * ,MAX(Vote_Get) FROM city_candidateinfo WHERE city='$seat' and Ctype='$type'  GROUP BY ward");
		  while($row = mysqli_fetch_array($result))
		  {
		        $a=$row['Name'];
				$b=$row['Team'];
				$c=$row['city'];
				$d=$row['Nid'];
				$e=$row['Ctype'];
				$f=$row['ward'];
				$ad=$row['Cphoto'];
				if($vote>0)
				{
				$result= mysqli_query($db,"INSERT INTO city_winner_list (Name,Team,City,Nid,Ctype,ward,image)VALUES('$a','$b','$c','$d','$e','$f','$ad')");
				}
		  }

}





if(strcasecmp( $type, 'Female_councilor' ) == 0)
{
$result = mysqli_query($db,"SELECT SUM(Vote_Get) FROM city_candidateinfo WHERE city='$seat' and Ctype='$type'");
$row = mysqli_fetch_array($result);
$cast=$row['SUM(Vote_Get)'];
//echo $total;
$result = mysqli_query($db,"SELECT COUNT(*) FROM city_corporation WHERE city='$seat'");
$row = mysqli_fetch_array($result);
$total=$row['COUNT(*)'];
echo "</br>";
$prct=($cast/$total)*100;
$sql="SELECT * FROM city_candidateinfo WHERE city='$seat' and Ctype='$type'";
$result=mysqli_query($db,$sql);
echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Name";echo"</td>"; 
echo "<th>"; echo "Ward";echo"</td>";
echo "<th>"; echo "Photo";echo"</td>";
echo "<th>"; echo "Team";echo"</td>";
echo "<th>"; echo "Candidate Type";echo"</td>";
echo "<th>"; echo "Vote Get";echo"</td>";
echo "</tr>";
while($row=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>".$row['Name']."</td>"; 
echo "<td>".$row['ward']."</td>";
$ad=$row['Cphoto'];
             echo "<td>";echo "<img style='float:center;border:3px solid black;border-radius:20px;width:100px;height:100px' src='".$ad."'>"; echo "</td>";
echo "<td>".$row['Team']."</td>";
echo "<td>".$row['Ctype']."</td>";
echo "<td>".$row['Vote_Get']."</td>";
echo "</tr>";
}

echo "</table>";
echo "Percentage Of Vote cast:".$prct;


      $result = mysqli_query($db,"SELECT *, MAX(Vote_Get) FROM city_candidateinfo WHERE city='$seat' and Ctype='$type'  GROUP BY ward");
		  while($row = mysqli_fetch_array($result))
		  {
		   
		        
		        $a=$row['Name'];
				$b=$row['Team'];
				$c=$row['city'];
				$d=$row['Nid'];
				$e=$row['Ctype'];
				$f=$row['ward'];
				$ad=$row['Cphoto'];
				$vote=$row['Vote_Get'];
				echo $a;
				if($vote>0)
				{
				$sql= mysqli_query($db,"INSERT INTO City_winner_list (Name,Team,City,Nid,Ctype,ward,image)VALUES('$a','$b','$c','$d','$e','$f','$ad')");
				}
		  }
		  


}

}

?>
  
    <div id="donutchart" style="width: 900px; height: 400px;"></div>
</body>
</html>
