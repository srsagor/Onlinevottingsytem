<?php
	define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
session_start();
$user_check=$_SESSION['login_user'];
$ses_sql=mysqli_fetch_array($db,"SELECT Nid FROM voter_login WHERE Nid='$user_check'";
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
$login_session=$row['Nid'];
if(!isset($_SESSION['login_user'])){
header("location:vote.php");
}
?>
