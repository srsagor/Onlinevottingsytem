<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','Voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE); 
   session_start();
  
if($_SERVER["REQUEST_METHOD"]=="POST")
{
		if (empty($_POST["Name"]))  
		{
		 echo '<script language="javascript">';
		echo 'alert("Name is Required")';
		echo '</script>';
		 } 
		 else 
			 {
		     
		if (!preg_match("/^[a-zA-Z ]*$/",$_POST["Name"]))
			 {
		echo '<script language="javascript">';
		echo 'alert("Name is Only alphabet letter")';
		echo '</script>';
			 }
			  }
					if (empty($_POST["Dob"])) 
					{
					echo '<script language="javascript">';
					echo 'alert("Age is empty")';
					echo '</script>';
					} 
							
					if (empty($_POST["pradress"]))
							 {
									echo '<script language="javascript">';
									echo 'alert("Present Address is Empty")';
									echo '</script>';
							  } 
							  
					if (empty($_POST["paadress"]))
						{
									 echo '<script language="javascript">';
									echo 'alert("Permanent Address is Empty")';
									echo '</script>';
						 } 
					
					
					if (empty($_POST["division"])) {
									echo '<script language="javascript">';
									echo 'alert("Division is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["dis"])) {
									echo '<script language="javascript">';
									echo 'alert("District is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["thana"])) {
									echo '<script language="javascript">';
									echo 'alert("Thana is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["Religion"])) {
									echo '<script language="javascript">';
									echo 'alert("Religion is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["Bac"])) {
									echo '<script language="javascript">';
									echo 'alert("Birth C/N is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["Fid"])) {
									echo '<script language="javascript">';
									echo 'alert("Father Nid Number is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["Mid"])) {
									echo '<script language="javascript">';
									echo 'alert("Mother Nid Number is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["SeatName"])) {
									echo '<script language="javascript">';
									echo 'alert("Seat Name is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["center"])) {
									echo '<script language="javascript">';
									echo 'alert("Center is Empty")';
									echo '</script>';
					} 
					if (empty($_POST["Nid"])) {
									echo '<script language="javascript">';
									echo 'alert("From Number is Empty")';
									echo '</script>';
					} 
					
					
if(!empty($_POST["Name"]) && preg_match("/^[a-zA-Z ]*$/",$_POST["Name"]) && !empty($_POST["Dob"])&& !empty($_POST["pradress"]) && !empty($_POST["paadress"]) && !empty($_POST["division"]) && !empty($_POST["dis"]) && !empty($_POST["thana"]) && !empty($_POST["Religion"]) && !empty($_POST["Bac"]) && !empty($_POST["Fid"]) && !empty($_POST["Mid"]) && !empty($_POST["SeatName"]) && !empty($_POST["center"]) && !empty($_POST["Nid"]))
				{
			$a=mysqli_real_escape_string($db,$_POST['Name']);
			$b=mysqli_real_escape_string($db,$_POST['Dob']);
			$c=mysqli_real_escape_string($db,$_POST['pradress']);
			$d=mysqli_real_escape_string($db,$_POST['paadress']);
			$e=mysqli_real_escape_string($db,$_POST['division']);
			$f=mysqli_real_escape_string($db,$_POST['dis']);
			$g=mysqli_real_escape_string($db,$_POST['thana']);
			$h=mysqli_real_escape_string($db,$_POST['gender']);
			$i=mysqli_real_escape_string($db,$_POST['Bac']);
			$j=mysqli_real_escape_string($db,$_POST['Fid']);
			$k=mysqli_real_escape_string($db,$_POST['Mid']);
			$l=mysqli_real_escape_string($db,$_POST['Religion']);
			$p=mysqli_real_escape_string($db,$_POST['SeatName']);
			$m=mysqli_real_escape_string($db,$_POST['center']);
			$n=mysqli_real_escape_string($db,$_POST['Nid']);
			
			
			
					 $destination = "../image/VoterPhoto/".$_FILES['image']['name'];
					 $filename    = $_FILES['image']['tmp_name'];  
			
					 move_uploaded_file($filename, $destination);
			
			$result = mysqli_query($db,"SELECT * FROM district WHERE District='$f' and Division='$e'");
			$row = mysqli_fetch_array($result);
			$dcode=$row['Code']; 
			$result = mysqli_query($db,"SELECT * FROM thana WHERE District='$f' and thana ='$g'");
			$row = mysqli_fetch_array($result);
			$Tcode=$row['Code'];
			
			$nid=$dcode.$Tcode.$n;
			
			$sql="INSERT INTO voterinfo(Name,Dob,Present,Permanent,Division,District,Thana,Religion,Birth,Gender,Father,Mother,Seat,Center,Nid,imagename,status) VALUES('$a','$b','$c','$d','$e','$f','$g','$l','$i','$h','$j','$k','$p','$m','$nid','$destination','NOT')";
			if($db->query($sql)===TRUE)
			{
			header:(adminpage.php);  
			}
			else
			{
			echo '<script language="javascript">';
			echo 'alert("Some things Wrong")';
			echo '</script>';
			}

       }
					
					
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>		
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Voter Regestion</title>
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
</style>
</head>

<body style="background-color:#0066CC">
<h1 style="border-bottom:hidden" style="width:100%"><img src="../image/pic.png"  width="123" height="77"/>Election Commission Bangladesh</h1>
<div class="container">
<div class="navbar">
 <a href="adminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="regestion.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voter Registration&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <div class="dropdown">
    <button class="dropbtn">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="entry.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="update.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Delete&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="delate.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Update&nbsp;&nbsp;&nbsp;&nbsp;</a>
  </div>
</div>
<a href="infochk.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Voter Information Change&nbsp;&nbsp;&nbsp;&nbsp;</a>

   <a href="resultCenter.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp; Cheak Center Result &nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="Acupdate.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Account Update&nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="logout.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;LogOut&nbsp;&nbsp;&nbsp;&nbsp; </a>
</div>
<div id="body" style="background-attachment:scroll">
<div id="left" style="background-color: #CCCCCC">
<br />
<?php
include("Config.php");
   session_start();
   $N=$_SESSION['myusername'];
   $sql="SELECT * FROM voterinfo WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
$ad= $row['imagename'];
echo "<img style='float:center;border:3px solid black;border-radius:20px;width:190px;height:250px' src='".$ad."'>";
echo "<br>";
echo "<br>";
echo "<font size='+2'>" . $row['Name'];
echo "<br>";

}
   $sql="SELECT * FROM admin WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
echo "Area:" . $row['Area'] ;
echo "<br>"."</font>";
echo "Post:" . $row['Post'] ;
echo "<br>";
echo "<font size='+2'>"."J_Date:" . $row['Join_date'] ;
echo "<br>";
echo "R_Date:" . $row['r_date'] ;
echo "<br>";
}
   ?>

</div>
<div id="right" style="background-color: #CCCCCC">
<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
      </MARQUEE><br />
		<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
		<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
        </MARQUEE>
</div>

<form  name="myForm"  onsubmit="return validateForm()" enctype="multipart/form-data"  method="post">

<table  align="center" style="width:69%">
<tr>
<th colspan="4" align="center"><h1>Voter Information Registration</h1></th>
</tr>
<tr>
<td>Name:</td>
<td><input type="text"  name="Name" /></td>
<td>Date Of Birth:</td>
<td><input type="date"  name="Dob" /></td>
</tr>
<tr>
<td><label>Present Address:</label></td>
<td><input type="text" name="pradress"  /></td>
<td><label>Permanent Address:</label></td>
<td><input type="text" name="paadress"  /></td>
</tr>
<tr>
<td><label>Division:</label></td>
<td><select name="division" id="divi" onChange="change_District()"/>
   <option value="" >Select One</option>
  <option value="Barisal">Barisal</option>
  <option value="Chittagong">Chittagong</option>
  <option value="Dhaka">Dhaka</option>
  <option value="Mymensingh">Mymensingh</option>
  <option value="Khulna">Khulna</option>
  <option value="Rajshahi">Rajshahi</option>
  <option value="Rangpur">Rangpur</option>
  <option value="Sylhet">Sylhet</option>
</select></td>
<td><label>District:</label></td>
<td>
<div id="dist">
<select name="dis" >
<option value=""> Select</option>
</select>
</div></td>
</tr>
<tr>
<td><label>Thana:</label></td>
<td>
<div id="than">
<select name="thana" >
<option value=""> Select</option>
</select>
</div></td>
<td><label>Religion:</label></td>
<td><select name="Religion" >
   <option value="">Select One</option>
  <option value="Islam">Islam</option>
  <option value="Hindu">Hindu</option>
  <option value="Khystian">Khystian</option>
  <option value="Budhu">Budhu</option>
</select></td>
</tr>
<tr>
<td><label>Gender:</label></td>
<td><input type="radio" name="gender" value="male" checked> Male
  <input type="radio" name="gender" value="female"> Female
  <input type="radio" name="gender" value="other"> Other</td>
<td><label>Birth C/N:</label></td>
<td><input type="text" name="Bac" /></td>
</tr>
<tr>
<td><label>Father Nid:</label></td>
<td><input type="text" name="Fid"  /></td>
<td><label>Mother Nid:</label></td>
<td><input type="text" name="Mid"  /></td>
</tr>
<tr>
<td><label>Seat Name:</label></td>
<td><select name="SeatName" id="seat"  onchange="change_Center()">
   <option >Select One</option>
     <option value="Panchagarh-1">Panchagarh-1</option>
	 <option value="Panchagarh-2">Panchagarh-2</option>
	 <option value="Thakurgaon-1">Thakurgaon-1</option>
	 <option value="Thakurgaon-2">Thakurgaon-2</option>
	 <option value="Thakurgaon-3">Thakurgaon-3</option>
	 <option value="Dinajpur-1">Dinajpur-1</option>
	 <option value="Dinajpur-2">Dinajpur-2</option>
	 <option value="Dinajpur-3">Dinajpur-3</option>
	 <option value="Dinajpur-4">Dinajpur-4</option>
	 <option value="Dinajpur-5">Dinajpur-5</option>
	 <option value="Dinajpur-6">Dinajpur-6</option>
	 <option value="Nilphamari-1">Nilphamari-1</option>
	 <option value="Nilphamari-2">Nilphamari-2</option>
	 <option value="Nilphamari-3">Nilphamari-3</option>
	 <option value="Nilphamari-4">Nilphamari-4</option>
	 <option value="Lalmonirhat-1">Lalmonirhat-1</option>
	 <option value="Lalmonirhat-2">Lalmonirhat-2</option>
	 <option value="Lalmonirhat-3">Lalmonirhat-3</option>
	 <option value="Rangpur-1">Rangpur-1</option>
	 <option value="Rangpur-2">Rangpur-2</option>
	 <option value="Rangpur-3">Rangpur-3</option>
	 <option value="Rangpur-4">Rangpur-4</option>
	 <option value="Rangpur-5">Rangpur-5</option>
	 <option value="Rangpur-6">Rangpur-6</option>
	 <option value="Kurigram-1">Kurigram-1</option>
	 <option value="Kurigram-2">Kurigram-2</option>
	 <option value="Kurigram-3">Kurigram-3</option>
	 <option value="Kurigram-4">Kurigram-4</option>
	 <option value="Gaibandha-1">Gaibandha-1</option>
	 <option value="Gaibandha-2">Gaibandha-2</option>
	 <option value="Gaibandha-3">Gaibandha-3</option>
	 <option value="Gaibandha-4">Gaibandha-4</option>
	 <option value="Gaibandha-5">Gaibandha-5</option>
	 <option value="Jaipurhat-1">Jaipurhat-1</option>
	 <option value="Jaipurhat-1">Jaipurhat-2</option>
	 <option value="Bogra-1">Bogra-1</option>
	 <option value="Bogra-2">Bogra-2</option>
	 <option value="Bogra-3">Bogra-3</option>
	 <option value="Bogra-4">Bogra-4</option>
	 <option value="Bogra-5">Bogra-5</option>
	 <option value="Bogra-6">Bogra-6</option>
	 <option value="Bogra-7">Bogra-7</option>
	 <option value="Chapai Nawabganj-1">Chapai Nawabganj-1</option>
	 <option value="Chapai Nawabganj-2">Chapai Nawabganj-2</option>
	 <option value="Chapai Nawabganj-3">Chapai Nawabganj-3</option>
	 <option value="Naogaon-1">Naogaon-1</option>
	 <option value="Naogaon-2">Naogaon-2</option>
	 <option value="Naogaon-3">Naogaon-3</option>
	 <option value="Naogaon-4">Naogaon-4</option>
	 <option value="Naogaon-5">Naogaon-5</option>
	 <option value="Naogaon-6">Naogaon-6</option>
	 <option value="Rajshahi-1">Rajshahi-1</option>
	 <option value="Rajshahi-2">Rajshahi-2</option>
	 <option value="Rajshahi-3">Rajshahi-3</option>
	 <option value="Rajshahi-4">Rajshahi-4</option>
	 <option value="Rajshahi-5">Rajshahi-5</option>
	 <option value="Rajshahi-6">Rajshahi-6</option>
	 <option value="Natore-1">Natore-1</option>
	 <option value="Natore-2">Natore-2</option>
	 <option value="Natore-3">Natore-3</option>
	 <option value="Natore-4">Natore-4</option>
	 <option value="Sirajganj-1">Sirajganj-1</option>
	 <option value="Sirajganj-2">Sirajganj-2</option>
	 <option value="Sirajganj-3">Sirajganj-3</option>
	 <option value="Sirajganj-4">Sirajganj-4</option>
	 <option value="Sirajganj-5">Sirajganj-5</option>
	 <option value="Sirajganj-6">Sirajganj-6</option>
	 <option value="Pabna-1">Pabna-1</option>
	 <option value="Pabna-2">Pabna-2</option>
	 <option value="Pabna-3">Pabna-3</option>
	 <option value="Pabna-4">Pabna-4</option>
	 <option value="Pabna-5">Pabna-5</option>
	 <option value="Meherpur-1">Meherpur-1</option>
	 <option value="Meherpur-2">Meherpur-2</option>
	 <option value="Kushtia-1">Kushtia-1</option>
	 <option value="Kushtia-2">Kushtia-2</option>
	 <option value="Kushtia-3">Kushtia-3</option>
	 <option value="Kushtia-4">Kushtia-4</option>
	 <option value="Chuadanga-1">Chuadanga-1</option>
	 <option value="Chuadanga-2">Chuadanga-2</option>
	 <option value="Jhenaidah-1">Jhenaidah-1</option>
	 <option value="Jhenaidah-2">Jhenaidah-2</option>
	 <option value="Jhenaidah-3">Jhenaidah-3</option>
	 <option value="Jhenaidah-4">Jhenaidah-4</option>
	 <option value="Jessore-1">Jessore-1</option>
	 <option value="Jessore-2">Jessore-2</option>
	 <option value="Jessore-3">Jessore-3</option>
	 <option value="Jessore-4">Jessore-4</option>
	 <option value="Jessore-5">Jessore-5</option>
	 <option value="Jessore-6">Jessore-6</option>
	 <option value="Magura -1">Magura -1</option>
	 <option value="Magura -1">Magura -2</option>
	 <option value="Narail-1">Narail-1</option>
	 <option value="Narail-2">Narail-2</option>
	 <option value="Bagerhat-1">Bagerhat-1</option>
	 <option value="Bagerhat-2">Bagerhat-2</option>
	 <option value="Bagerhat-3">Bagerhat-3</option>
	 <option value="Bagerhat-4">Bagerhat-4</option>
	 <option value="Khulna-1">Khulna-1</option>
	 <option value="Khulna-2">Khulna-2</option>
	 <option value="Khulna-3">Khulna-3</option>
	 <option value="Khulna-4">Khulna-4</option>
	 <option value="Khulna-5">Khulna-5</option>
	 <option value="Khulna-6">Khulna-6</option>
	 <option value="Satkhira-1">Satkhira-1</option>
	 <option value="Satkhira-2">Satkhira-2</option>
	 <option value="Satkhira-3">Satkhira-3</option>
	 <option value="Satkhira-4">Satkhira-4</option>
	 <option value="Barguna-1">Barguna-1</option>
	 <option value="Barguna-2">Barguna-2</option>
	 <option value="Patuakhali-1">Patuakhali-1</option>
	 <option value="Patuakhali-2">Patuakhali-2</option>
	 <option value="Patuakhali-3">Patuakhali-3</option>
	 <option value="Patuakhali-4">Patuakhali-4</option>
	 <option value="Bhola-1">Bhola-1</option>
	 <option value="Bhola-2">Bhola-2</option>
	 <option value="Bhola-3">Bhola-3</option>
	 <option value="Bhola-4">Bhola-4</option>
	 <option value="Barisal-1">Barisal-1</option>
	 <option value="Barisal-2">Barisal-2</option>
	 <option value="Barisal-3">Barisal-3</option>
	 <option value="Barisal-4">Barisal-4</option>
	 <option value="Barisal-5">Barisal-5</option>
	 <option value="Barisal-6">Barisal-6</option>
	 <option value="Jhalokathi-1">Jhalokathi-1</option>
	 <option value="Jhalokathi-2">Jhalokathi-2</option>
	 <option value="Pirojpur-1">Pirojpur-1</option>
	 <option value="Pirojpur-2">Pirojpur-2</option>
	 <option value="Pirojpur-4">Pirojpur-3</option>
	 <option value="Tangail-1">Tangail-1</option>
	 <option value="Tangail-2">Tangail-2</option>
	 <option value="Tangail-3">Tangail-3</option>
	 <option value="Tangail-4">Tangail-4</option>
	 <option value="Tangail-5">Tangail-5</option>
	 <option value="Tangail-6">Tangail-6</option>
	 <option value="Tangail-7">Tangail-7</option>
	 <option value="Tangail-8">Tangail-8</option>
	 <option value="Jamalpur-1">Jamalpur-1</option>
	 <option value="Jamalpur-2">Jamalpur-2</option>
	 <option value="Jamalpur-3">Jamalpur-3</option>
	 <option value="Jamalpur-4">Jamalpur-4</option>
	 <option value="Jamalpur-5">Jamalpur-5</option>
	 <option value="Sherpur-1">Sherpur-1</option>
	 <option value="Sherpur-2">Sherpur-2</option>
	 <option value="Sherpur-3">Sherpur-3</option>
	  <option value="Mymensingh-1">Mymensingh-1</option>
	 <option value="Mymensingh-2">Mymensingh-2</option>
	 <option value="Mymensingh-3">Mymensingh-3</option>
	 <option value="Mymensingh-4">Mymensingh-4</option>
	 <option value="Mymensingh-5">Mymensingh-5</option>
	 <option value="Mymensingh-6">Mymensingh-6</option>
	 <option value="Mymensingh-7">Mymensingh-7</option>
	 <option value="Mymensingh-8">Mymensingh-8</option>
	 <option value="Mymensingh-9">Mymensingh-9</option>
	 <option value="Mymensingh-10">Mymensingh-10</option>
	 <option value="Mymensingh-11">Mymensingh-11</option>
	 <option value="Netrokona-1">Netrokona-1</option>
	 <option value="Netrokona-2">Netrokona-2</option>
	 <option value="Netrokona-3">Netrokona-3</option>
	 <option value="Netrokona-4">Netrokona-4</option>
	 <option value="Netrokona-5">Netrokona-5</option>
	 <option value="Kishoreganj-1">Kishoreganj-1</option>
	 <option value="Kishoreganj-2">Kishoreganj-2</option>
	 <option value="Kishoreganj-3">Kishoreganj-3</option>
	 <option value="Kishoreganj-4">Kishoreganj-4</option>
	 <option value="Kishoreganj-5">Kishoreganj-5</option>
	 <option value="Kishoreganj-6">Kishoreganj-6</option>
	 <option value="Manikganj-1">Manikganj-1</option>
	 <option value="Manikganj-2">Manikganj-2</option>
	 <option value="Manikganj-3">Manikganj-3</option>
	 <option value="Munshiganj-1">Munshiganj-1</option>
	 <option value="Munshiganj-2">Munshiganj-2</option>
	 <option value="Munshiganj-3">Munshiganj-3</option>
	 <option value="Dhaka-1">Dhaka-1</option>
	 <option value="Dhaka-2">Dhaka-2</option>
	 <option value="Dhaka-3">Dhaka-3</option>
	 <option value="Dhaka-4">Dhaka-4</option>
	 <option value="Dhaka-5">Dhaka-5</option>
	 <option value="Dhaka-6">Dhaka-6</option>
	 <option value="Dhaka-7">Dhaka-7</option>
	 <option value="Dhaka-8">Dhaka-8</option>
	 <option value="Dhaka-9">Dhaka-9</option>
	 <option value="Dhaka-10">Dhaka-10</option>
	 <option value="Dhaka-11">Dhaka-11</option>
	 <option value="Dhaka-12">Dhaka-12</option>
	 <option value="Dhaka-13">Dhaka-13</option>
	 <option value="Dhaka-14">Dhaka-14</option>
	 <option value="Dhaka-15">Dhaka-15</option>
	 <option value="Dhaka-16">Dhaka-16</option>
	 <option value="Dhaka-17">Dhaka-17</option>
	 <option value="Dhaka-18">Dhaka-18</option>
	 <option value="Dhaka-19">Dhaka-19</option>
	 <option value="Dhaka-20">Dhaka-20</option>
	 <option value="Gazipur-1">Gazipur-1</option>
	 <option value="Gazipur-2">Gazipur-2</option>
	 <option value="Gazipur-3">Gazipur-3</option>
	 <option value="Gazipur-4">Gazipur-4</option>
	 <option value="Gazipur-5">Gazipur-5</option>
	 <option value="Narsingdi-1">Narsingdi-1</option>
	 <option value="Narsingdi-2">Narsingdi-2</option>
	 <option value="Narsingdi-3">Narsingdi-3</option>
	 <option value="Narsingdi-4">Narsingdi-4</option>
	 <option value="Narsingdi-5">Narsingdi-5</option>
	 <option value="Narayanganj-1">Narayanganj-1</option>
	 <option value="Narayanganj-2">Narayanganj-2</option>
	 <option value="Narayanganj-3">Narayanganj-3</option>
	 <option value="Narayanganj-4">Narayanganj-4</option>
	 <option value="Narayanganj-5">Narayanganj-5</option>
	 <option value="Rajbari-1">Rajbari-1</option>
	 <option value="Rajbari-2">Rajbari-2</option>
	 <option value="Faridpur-1">Faridpur-1</option>
	 <option value="Faridpur-2">Faridpur-2</option>
	 <option value="Faridpur-3">Faridpur-3</option>
	 <option value="Faridpur-4">Faridpur-4</option>
	 <option value="Gopalgonj-1">Gopalgonj-1</option>
	 <option value="Gopalgonj-2">Gopalgonj-2</option>
	 <option value="Gopalgonj-3">Gopalgonj-3</option>
	 <option value="Madaripur-1">Madaripur-1</option>
	 <option value="Madaripur-2">Madaripur-2</option>
	 <option value="Madaripur-3">Madaripur-3</option>
	 <option value="Shariatpur-1">Shariatpur-1</option>
	 <option value="Shariatpur-2">Shariatpur-2</option>
	 <option value="Shariatpur-3">Shariatpur-3</option>
	 <option value="Sunamganj-1">Sunamganj-1</option>
	 <option value="Sunamganj-2">Sunamganj-2</option>
	 <option value="Sunamganj-3">Sunamganj-3</option>
	 <option value="Sunamganj-4">Sunamganj-4</option>
	 <option value="Sunamganj-5">Sunamganj-5</option>
	 <option value="Sylhet-1">Sylhet-1</option>
	 <option value="Sylhet-2">Sylhet-2</option>
	 <option value="Sylhet-3">Sylhet-3</option>
	 <option value="Sylhet-4">Sylhet-4</option>
	 <option value="Sylhet-5">Sylhet-5</option>

	 <option value="Sylhet-6">Sylhet-6</option>
	 <option value="Maulvibazar-1">Maulvibazar-1</option>
	 <option value="Maulvibazar-2">Maulvibazar-2</option>
	 <option value="Maulvibazar-3">Maulvibazar-3</option>
	 <option value="Maulvibazar-4">Maulvibazar-4</option>
	 <option value="Habiganj-1">Habiganj-1</option>
	 <option value="Habiganj-2">Habiganj-2</option>
	 <option value="Habiganj-3">Habiganj-3</option>
	 <option value="Habiganj-4">Habiganj-4</option>
	 <option value="Brahmanbaria-1">Brahmanbaria-1</option>
	 <option value="Brahmanbaria-2">Brahmanbaria-2</option>
	 <option value="Brahmanbaria-3">Brahmanbaria-3</option>
	 <option value="Brahmanbaria-4">Brahmanbaria-4</option>
	 <option value="Brahmanbaria-5">Brahmanbaria-5</option>
	 <option value="Brahmanbaria-6">Brahmanbaria-6</option>
	 <option value="Comilla-1">Comilla-1</option>
	 <option value="Comilla-2">Comilla-2</option>
	 <option value="Comilla-3">Comilla-3</option>
	 <option value="Comilla-4">Comilla-4</option>
	 <option value="Comilla-5">Comilla-5</option>
	 <option value="Comilla-6">Comilla-6</option>
	 <option value="Comilla-7">Comilla-7</option>
	 <option value="Comilla-8">Comilla-8</option>
	 <option value="Comilla-9">Comilla-9</option>
	 <option value="Comilla-10">Comilla-10</option>
	 <option value="Comilla-11">Comilla-11</option>
	 <option value="Chandpur-1">Chandpur-1</option>
	 <option value="Chandpur-2">Chandpur-2</option>
	 <option value="Chandpur-3">Chandpur-3</option>
	 <option value="Chandpur-4">Chandpur-4</option>
	 <option value="Chandpur-5">Chandpur-5</option>
	 <option value="Feni-1">Feni-1</option>
	 <option value="Feni-2">Feni-2</option>
	 <option value="Feni-3">Feni-3</option>
	 <option value="Noakhali-1">Noakhali-1</option>
	 <option value="Noakhali-2">Noakhali-2</option>
	 <option value="Noakhali-3">Noakhali-3</option>
	 <option value="Noakhali-4">Noakhali-4</option>
	 <option value="Noakhali-5">Noakhali-5</option>
	 <option value="Noakhali-6">Noakhali-6</option>
	 <option value="Laxmipur-1">Laxmipur-1</option>
	 <option value="Laxmipur-2">Laxmipur-2</option>
	 <option value="Laxmipur-3">Laxmipur-3</option>
	 <option value="Laxmipur-4">Laxmipur-4</option>
	 <option value="Chittagong-1">Chittagong-1</option>
	 <option value="Chittagong-2">Chittagong-2</option>
	 <option value="Chittagong-3">Chittagong-3</option>
	 <option value="Chittagong-4">Chittagong-4</option>
	 <option value="Chittagong-5">Chittagong-5</option>
	 <option value="Chittagong-6">Chittagong-6</option>
	 <option value="Chittagong-7">Chittagong-7</option>
	 <option value="Chittagong-8">Chittagong-8</option>
	 <option value="Chittagong-9">Chittagong-9</option>
	 <option value="Chittagong-10">Chittagong-10</option>
	 <option value="Chittagong-11">Chittagong-11</option>
	 <option value="Chittagong-12">Chittagong-12</option>
	 <option value="Chittagong-13">Chittagong-13</option>
	 <option value="Chittagong-14">Chittagong-14</option>
	 <option value="Chittagong-15">Chittagong-15</option>
	 <option value="Chittagong-16">Chittagong-16</option>
	 <option value="Cox's Bazar-1">Cox's Bazar-1</option>
	 <option value="Cox's Bazar-2">Cox's Bazar-2</option>
	 <option value="Cox's Bazar-3">Cox's Bazar-3</option>
	 <option value="Cox's Bazar-4">Cox's Bazar-4</option>
	 <option value="Khagrachhari">Khagrachhari</option>
	 <option value="Rangamati">Rangamati</option>
	 <option value="Bandarban">Bandarban</option>
  </select></td>
<td><label>Center:</label></td>
<td><div id="seats">
<select name="center" >
<option>Select</option>
</select>
</div></td>
</tr>
<tr>
<td><label>Form Number:</label></td>
<td><input type="number" name="Nid"  min="1000000" max="9999999" /></td>
</tr>
<tr>
<td><label>Image:</label></td>
<td colspan="4"><input type="file" value="" name="image" required/></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
  <td colspan="4"><h1>
    <input name="submit" type="submit" value="submit" class="button" align="right"   />
  </h1></td>
</tr>

</table>
</form>
<script type="text/javascript">
function change_District()
{
var xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","ajax.php?division="+document.getElementById("divi").value,false);
xmlhttp.send(null);
alert=(xmlhttp.responseText);
document.getElementById("dist").innerHTML=xmlhttp.responseText;
}
function change_thana()
{
var xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","ajax.php?district="+document.getElementById("thanas").value,false);
xmlhttp.send(null);
alert=(xmlhttp.responseText);
document.getElementById("than").innerHTML=xmlhttp.responseText;
}

function change_Center()
{
var xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","ajax.php?seatinfo="+document.getElementById("seat").value,false);
xmlhttp.send(null);
alert=(xmlhttp.responseText);
document.getElementById("seats").innerHTML=xmlhttp.responseText;
}
</script>
</div>
    
</div>
</body>
</html>
