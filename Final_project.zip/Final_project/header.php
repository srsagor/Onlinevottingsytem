<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="CSS/style.css">
</head>

<body>
<div class="navbar">
 <a href="adminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="regestion.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voter Registion&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <div class="dropdown">
    <button class="dropbtn">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="entry.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="update.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Delete&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="delate.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Update&nbsp;&nbsp;&nbsp;&nbsp;</a>
  </div>
</div>
<a href="infochk.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Voter Information Change&nbsp;&nbsp;&nbsp;&nbsp;</a>

   <a href="resultCenter.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp; Cheak Center Result &nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="Acupdate.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Account Update&nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="logout.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;LogOut&nbsp;&nbsp;&nbsp;&nbsp; </a>
	</div>
</body>
</html>
