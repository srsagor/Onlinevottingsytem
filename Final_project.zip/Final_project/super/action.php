<?php 
    include("config.php");
	
 	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo");
	$row = mysqli_fetch_array($result);
	$total_voter=$row['COUNT(*)'];
	//echo $total_voter;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='male'");
	$row = mysqli_fetch_array($result);
	$total_male_voter=$row['COUNT(*)'];
	//echo $total_male_voter;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='female'");
	$row = mysqli_fetch_array($result);
	$total_female_voter=$row['COUNT(*)'];
	//echo $total_female_voter;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where status='YES'");
	$row = mysqli_fetch_array($result);
	$total_votecast=$row['COUNT(*)'];
	//echo $total_votecast;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='male' and status='YES'");
	$row = mysqli_fetch_array($result);
	$total_male_votecast=$row['COUNT(*)'];
	//echo $total_male_votecast;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='female' and status='YES'");
	$row = mysqli_fetch_array($result);
	$total_female_votecast=$row['COUNT(*)'];
	//echo $total_female_votecast;
	
	
	$sql=mysqli_query($db,"INSERT INTO  summary (year,total_voter,total_male_voter,total_female_voter,total_vote_cast,total_male_voter_cast,total_female_voter_cast) VALUES('2018','$total_voter','$total_male_voter','$total_female_voter','$total_votecast','$total_male_votecast','$total_female_votecast')");
	
	
	
	
	
	
	$sql=mysqli_query($db,"SELECT *  FROM candidateinfo ");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $Nid=$row['Nid'];
		   $voteget=$row['VoteGet'];
		   $team=$row['Team'];
		   $seat=$row['Seat'];
		   //echo $Nid.$voteget.$team.$seat;
		   $result=mysqli_query($db,"INSERT INTO  yearhistory (year,Nid,vote_get,Team,Seat) VALUES('2018','$Nid','$voteget','$team','$seat')");
		   
		  }
		 
		 
		 
		 $sql=mysqli_query($db,"SELECT *  FROM winner_list  ");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $Nid=$row['Nid'];
		   $team=$row['Team'];
		   $seat=$row['Seat'];
		  // echo $Nid.$team.$seat;
		  $result=mysqli_query($db,"INSERT INTO  parliamentlist (year,Nid,Team,Seat) VALUES('2018','$Nid','$team','$seat')");
		   
		  }
		  
		  
		  $sql=mysqli_query($db,"SELECT *, COUNT(Name) AS seat FROM winner_list  GROUP BY Team");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $team=$row['Team'];
		   $seat=$row['seat'];
		    //echo $team.$seat;
			 $result=mysqli_query($db,"INSERT INTO  teamhistory (year,Total_voter,Team,Voteget,Seatget) VALUES('2019','$total_voter','$team','','$seat')");
		  }
		 
		  $sql=mysqli_query($db,"SELECT *, SUM(VoteGet) AS vote FROM candidateinfo  GROUP BY Team");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $team=$row['Team'];
		   $Vote=$row['vote'];
		    //echo $team.$Vote;
			$result=mysqli_query($db,"UPDATE teamhistory SET VoteGet='$Vote' WHERE year='2018' and Team='$team'");
			header("location:active.php");
		  }
		  
?> 