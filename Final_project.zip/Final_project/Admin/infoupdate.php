<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','Voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE); 
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST")
{

$userid=mysqli_real_escape_string($db,$_POST['userid']);
$new=mysqli_real_escape_string($db,$_POST['new']);
$old=mysqli_real_escape_string($db,$_POST['old']);
$sql="UPDATE admin SET passcode='$new' WHERE Nid='$userid'"; 
if($db->query($sql)===TRUE)
{

header("location:adminpage.php");
}
}


?>
<!DOCTYPE html>
<html>
<head >
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
<title>Admin Page</title>
</head>
<body style="background-color:#0066CC">
 <h1 style="border-bottom:hidden" style="width:100%"><img src="../image/pic.png"  width="101" height="69"/>Election Commission Bangladesh</h1>
<div class="container">
<div class="navbar">
 <a href="adminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="regestion.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voter Registion&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <div class="dropdown">
    <button class="dropbtn">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="entry.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="update.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Delete&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="delate.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Update&nbsp;&nbsp;&nbsp;&nbsp;</a>
  </div>
</div>
<a href="infochk.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Voter Information Change&nbsp;&nbsp;&nbsp;&nbsp;</a>

   <a href="resultCenter.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp; Cheak Center Result &nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="infoupdate.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Account Update&nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="logout.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;LogOut&nbsp;&nbsp;&nbsp;&nbsp; </a>
</div>
<div id="body" style="display:block">
<div id="left"  style="background-color: #CCCCCC">
<?php
include("Config.php");
   session_start();
   $N=$_SESSION['myusername'];
   $sql="SELECT * FROM voterinfo WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
$ad= $row['imagename'];
echo "<img style='float:center;border:3px solid black;border-radius:20px;width:190px;height:250px' src='".$ad."'>";
echo "<br>";
echo "<br>";
echo "<font size='+2'>" . $row['Name'];
echo "<br>";

}
   $sql="SELECT * FROM admin WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
echo "Area:" . $row['Area'] ;
echo "<br>"."</font>";
echo "Post:" . $row['Post'] ;
echo "<br>";
echo "<font size='+2'>"."J_Date:" . $row['Join_date'] ;
echo "<br>";
echo "R_Date:" . $row['r_date'] ;
echo "<br>";
}
   ?>
</div>
<div id="right" style="background-color: #CCCCCC">
<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
      </MARQUEE><br />
		<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
		<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
        </MARQUEE>
</div>
<br>
<form  method="post" align="center">
<b >Change Password</b><br>
<label>Enter User Name:</label><br/>
<input type="text" name="userid" required /><br/>
<label>Enter New Password:</label><br/>
<input type="text" name="new" required /><br/>
<label>Enter Old Password:</label><br/>
<input type="text" name="old" required /><br/><br/>
<input type="submit" value="change" class="button" />
</form>
</div>
</div>
</body>
</html>
