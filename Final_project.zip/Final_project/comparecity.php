<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="CSS/style.css">
<title>Untitled Document</title>
</head>

<body>

<h1 align="center"style="border-bottom:hidden">Election Commission Bangladesh</h1>


<div class="navbar">
 <a href="index12.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="super/superadmin_login.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Super Admin Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a  href="Admin/admin_login.php" style="text-decoration:none" style="display:block" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Admin Login &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="last.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Show result probability&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
   <a href="list.php" style="text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Election Commissioner list&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="notice.php" style="text-decoration:none"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Notice&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
</div>
<form align="center" method="post">
<label>Select Any Year to see result</label> <br />
<select name="year" required>
<option value="1991">1991</option>
<option value="1996">1996</option>
<option value="2001">2001</option>
<option value="2008">2008</option>
<option value="2014">2014</option>
</select>
</br>
<label>City Corporation Name:</label><br />
<select name="city" required>
     <option value="">Select One</option>
      <option value="Dhaka">Dhaka City </option>
	 <option value="Rajshahi">Rajshahi</option>
	 <option value="Khulna">Khulna</option>
	 <option value="Barisal">Barisal</option>
	 <option value="ctg">ctg</option>
	 <option value="Dinajpur-1">Dinajpur-1</option>
	 <option value="Dinajpur-2">Dinajpur-2</option>
	 <option value="Dinajpur-3">Dinajpur-3</option>
	 <option value="Dinajpur-4">Dinajpur-4</option>
	 <option value="Dinajpur-5">Dinajpur-5</option>
   </select><br />
<input type="submit" value="show" />
</form>
<?php
define('DB_SERVER','localhost');
		define('DB_USERNAME','root');
		define('DB_PASSWORD','');
		define('DB_DATABASE','voting');
		$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
		if($_SERVER["REQUEST_METHOD"]=="POST")
{
 $year = mysqli_real_escape_string($db,$_POST['year']);
 $city = mysqli_real_escape_string($db,$_POST['city']);
 
   $sql=mysqli_query($db,"SELECT *  FROM city_winner_list WHERE year='$year'and city='$city'");
   echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Year";echo"</td>"; 
echo "<th>"; echo "Name";echo"</td>";
echo "<th>"; echo "City";echo"</td>";
echo "<th>"; echo "Candidate Type";echo"</td>";
echo "<th>"; echo "Ward";echo"</td>";
echo "<th>"; echo "Image";echo"</td>";
echo "</tr>";
		  while($row = mysqli_fetch_array($sql))

			{
				echo "<tr>";
                 echo "<td>".$row['year']."</td>"; 
				 echo "<td>".$row['Name']."</td>"; 
				
				 echo "<td>".$row['city']."</td>"; 
				 echo "<td>".$row['Ctype']."</td>"; 
				 echo "<td>".$row['ward']."</td>";
				 $tvc=$row['image']; 
				 echo "<td>";echo "<img style='float:center;border:3px solid black;border-radius:20px;width:100px;height:100px' src='".$tvc."'>";echo"</td>";
				 echo "</tr>";
			}
			echo "</table>";
			
}

?>

</body>
</html>
