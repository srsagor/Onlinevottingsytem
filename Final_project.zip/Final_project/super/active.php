<?php
include("Config.php");
   session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Election Commissioner</title>
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body style="background-color:#0066CC">
 <h1 style="border-bottom:hidden" style="width:100%"><img src="../image/pic.png"  width="101" height="69"/>Election Commission Bangladesh</h1>
<div class="navbar" align="center">
<a href="Sadminpage.php" style="text-decoration:none" style="display:block">Home</font>
  <a href="adminadd.php" style="text-decoration:none" style="display:block">Returning Officer Add</a>
   <a href="candidateadd.php" style="text-decoration:none" style="display:block">National election</a>
<a href="teamadd.php" style="text-decoration:none" style="display:block">Add Party </a>
<a href="overallresult.php" style="text-decoration:none" style="display:block">Overall Result </a>
	<a href="Seatresult.php" style="text-decoration:none" style="display:block">Winner List </a>
	<a href="allinfo.php" style="text-decoration:none" style="display:block">Final Result</a>
<div class="dropdown">
    <button class="dropbtn">Election Update
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
   <a href="electionadd.php" style="text-decoration:none" style="display:block">Election Add</a>
	<a href="electiondlet.php" style="text-decoration:none" style="display:block">Election Delete</a>
  </div>
</div>
<a href="active.php" style="text-decoration:none" style="display:block">Active Election</a>
<a href="upload.php" style="text-decoration:none" style="display:block">Notice</a>
</div>
<div id="body" style="display:block">
<div id="left"  style="background-color: #CCCCCC">
<?php
include("Config.php");
   session_start();
   $N=$_SESSION['myusername'];
   $sql="SELECT * FROM voterinfo WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
		
		date_default_timezone_set('Asia/Dhaka');
		echo "<font size='+1'>";
		echo date("l jS \ F Y ") . "<br>";
		echo "<font>";
		echo "<br>";
			$ad="../super/".$row['imagename'];
			echo "<img style='float:center; border-radius:200;width:180px;height:250px' src='".$ad."'>";
			echo "<br>";
			echo "<font size='+2'>" . $row['Name']."</font>";
			echo "<br>";
   $sql="SELECT * FROM sadmin WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
echo "<font size='+1'>" . $row['Post']."</font>";
echo "<br>";
echo "<font size='+2'>" ."J_Date:" . $row['Join_date'] ;
echo "<br>";
echo "R_Date:" . $row['r_date'] ;
echo "<br>";
}
}
?>
<a href="logout.php" style="text-decoration:none" style="display:block"><img src="../image/logout-button-png-hi.png" height="50" width="80" /></a>
</div>
<div id="right" style="background-color: #CCCCCC">
<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
    </MARQUEE><br />
		<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
        </MARQUEE>
</div>
<?php

define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
$sql="SELECT * FROM  `level` ";
$result=mysqli_query($db,$sql);

echo "<table border='1' width='69%'>
<tr>
<th>Name Of Election</th>
<th> Status Of Election</th>
</tr>";
while($row=mysqli_fetch_array($result))
{
echo "<tr>";
echo"<td>".$row['vote_type']."</td>";
echo "<td>";
echo'<form method="post" action="activepage.php">
  <input type="hidden" name="election" value='.$row['vote_type'].'>
  <input type="submit" name="stu" class="button" value='.$row['status'].'>
  <button type="submit"  class="button" formaction="action.php">Store Result</button>';
  echo"</form>";
  echo "</td>";
  echo "</tr>";
}
echo "</table>";

?>
</div>
</div>
</body>
</html>