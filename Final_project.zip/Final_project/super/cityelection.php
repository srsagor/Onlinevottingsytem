<?php 
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$name=mysqli_real_escape_string($db,$_POST['Name']);
$type=mysqli_real_escape_string($db,$_POST['type']);
$nid=mysqli_real_escape_string($db,$_POST['Nid']);
$ward=mysqli_real_escape_string($db,$_POST['center']);
$team=mysqli_real_escape_string($db,$_POST['team']);
$year=mysqli_real_escape_string($db,$_POST['year']);
$seat=mysqli_real_escape_string($db,$_POST['Seat']);
         $destination = "../image/TeamPhoto/".$_FILES['image']['name'];
         $filename    = $_FILES['image']['tmp_name']; 
		 move_uploaded_file($filename, $destination);
		 
$sql="SELECT * FROM voterinfo WHERE Nid='$nid'";
$result=mysqli_query($db,$sql);
while($row = mysqli_fetch_array($result))
{
$image="../admin/".$row['imagename'];
}
$sql="INSERT INTO city_candidateinfo (Name,Nid,Ctype,Team,city,ward,image,Cphoto,year,Vote_Get) VALUES('$name','$nid','$type','$team','$seat','$ward','$destination','$image','$year','0')";
if($db->query($sql)===TRUE)
{
header("location:sadminpage.php");
}
else
{
echo "Error".$sql."<br>".$conn->error;
}
}
?>
<?php 
//include(config.php);
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
$sql="SELECT * FROM  `team_name` ";
$result=mysqli_query($db,$sql);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>

<body>
<h1 align="center" style="background-color:#00CCFF" style="border-bottom:hidden" style="width:100%">Election Commission Bangladesh</h1></td>
<div class="navbar">
 <a href="Sadminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="adminadd.php" style="text-decoration:none" style="display:block">Admin Add</a>
  <div class="dropdown">
    <button class="dropbtn">Candidate Add 
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="candidateadd.php" style="text-decoration:none" style="display:block">National election</a>
    <a href="cityelection.php" style="text-decoration:none" style="display:block">City election</a>
  </div>
</div>
<a href="teamadd.php" style="text-decoration:none" style="display:block">Team add </a>

<div class="dropdown">
    <button class="dropbtn">National Election
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="overallresult.php" style="text-decoration:none" style="display:block">Over all result </a>
	<a href="Seatresult.php" style="text-decoration:none" style="display:block">Winner List </a>
	<a href="allinfo.php" style="text-decoration:none" style="display:block">Final Result</a>
  </div>
</div>

<div class="dropdown">
    <button class="dropbtn">City Corporation Result
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="cityresult.php" style="text-decoration:none" style="display:block">City Corporation Result</a>
	<a href="citywinerlist.php" style="text-decoration:none" style="display:block">Winner List </a>
  </div>
</div>
<a href="storeresult.php" style="text-decoration:none" style="display:block">Store Result</a>
<div class="dropdown">
    <button class="dropbtn">Election Update
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
   <a href="electionadd.php" style="text-decoration:none" style="display:block">Election Add</a>
	<a href="electiondlet.php" style="text-decoration:none" style="display:block">Election Delate</a>
  </div>
</div>
<a href="active.php" style="text-decoration:none" style="display:block">Active Election</a>
<a href="upload.php" style="text-decoration:none" style="display:block">Notice</a>
</div>


<form method="post" enctype="multipart/form-data">
<table  align="center" style="width:100%">
<tr>
<th colspan="4" align="center"><h1>Candisate Add </h1></th>
</tr>
<tr>
<td >Name:</td>
<td><input type="text" name="Name" required/></td>
</tr>
<tr>
<td>NID:</td>
<td><input type="text" name="Nid" required/></td>
</tr>
<tr>
<tr>
<td><label>Candidate Type:</label></td>
<td><select name="type" required>
      <option value="Myeor">Myeor</option>
	 <option value="councilor">councilor</option>
	 <option value="Female_councilor">Female_councilor</option>
   </select>
</td>
</tr>
<tr>
<td><label>Team:</label></td>
<td>
<select name="team" required>
<?php while($row= mysqli_fetch_array($result)):;?>
<option value="<?php echo $row[0];?>"><?php echo $row[0];?></option>
<?php endwhile;?>
</select>
</td>
</tr>
<tr>
<td><label>City Corporation Name:</label></td>
<td><select name="Seat" required>
     <option value="---------">Select One</option>
      <option value="Dhaka">Dhaka City </option>
	 <option value="Rajshahi">Rajshahi</option>
	 <option value="Khulna">Khulna</option>
	 <option value="Barisal">Barisal</option>
	 <option value="ctg">ctg</option>
	 <option value="Dinajpur-1">Dinajpur-1</option>
	 <option value="Dinajpur-2">Dinajpur-2</option>
	 <option value="Dinajpur-3">Dinajpur-3</option>
	 <option value="Dinajpur-4">Dinajpur-4</option>
	 <option value="Dinajpur-5">Dinajpur-5</option>
   </select>
</td>
</tr>
<tr>
<td><label>ward:</label></td>
<td><div id="seats">
<select name="center">
<option>Select</option>
</select>
</div></td>
</tr>
<tr>
<td><label>Image:</label></td>
<td colspan="4"><input type="file" value="" name="image" required /></td>
</tr>
<tr>
<td><label>Year</label></td>
<td><input type="number" name="year" required/></td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="sumbit" /></td>
</tr>
</table>
</form>
</body>
</html>
