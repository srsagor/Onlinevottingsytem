<?php 
//include(config.php);
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$id=mysqli_real_escape_string($db,$_POST['Nid']);
$dob=mysqli_real_escape_string($db,$_POST['bod']);
$sql="SELECT * FROM  city_corporation WHERE Nid='$id' and DoB='$dob' and status='NOT'";
$result=mysqli_query($db,$sql);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
$active=$row['active'];
$count=mysqli_num_rows($result);
if($count==1)
{
	session_register("id");
	$_SESSION['login_user']=$id;
	header("location:vote.php");
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body background="../../image/pic.png">
<h1 align="center">Bangladesh Election </h1>
<form method="post"align="center" >
<label>Enter Nid</label>
<input type="text" name="Nid" />
<label>Date OF Birth</label>
<input type="date" name="bod" />
<input type="submit" value="Login" />
</form>
</body>
</html>
