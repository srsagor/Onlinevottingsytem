<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Election Commission Bangladesh</title>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <style>
div.container {
    width: 100%;
	height:auto;
    border: 1px solid gray;
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}

nav {
    float: left;
    max-width: 160px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
    padding: 0;
}
   
nav ul a {
    text-decoration: none;
}

article {
    margin-left: 170px;
    border-left: 1px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>
</head>

<body>
<div class="container" >
<header>
  <table width="100%" >
<tr rowspan="3">
<td colspan="7"><h1 style="border-bottom:hidden" style="width:100%"><img src="image/pic.png"  width="101" height="69"/>Election Commission Bangladesh</h1></td>
</tr>
<tr>
<td style="background-color: #333;font-size: 16px;color: white;text-align: center;"><a href="index.php" style="text-decoration:none" style="display:block">Home</td>
<td style="background-color: #333;font-size: 16px;color: white;text-align: center;"><a  href="Admin/admin_login.php" style="text-decoration:none" style="display:block" >Returning Officer Login</td>
<td style="background-color: #333;font-size: 16px;color: white;text-align: center;"><a href="super/superadmin_login.php" style="text-decoration:none" style="display:block"> Election Commissioner Login</td>
<td style="background-color: #333;font-size: 16px;color: white;text-align: center;"><a href="last.php" style="text-decoration:none" style="display:block">Show Projected Result</td>
<td style="background-color: #333;font-size: 16px;color: white;text-align: center;"><a href="list.php" style="text-decoration:none">Election Commissioner List</td>
<td style="background-color: #333;font-size: 16px;color: white;text-align: center;"><a href="notice.php" style="text-decoration:none">Notice</td>
</tr>
</table>
</header>
  
<nav>
  <ul>
    <li><a href="compare.php">National Election Result </a></li>
  </ul>
</nav>

<article style="background-color: #009933">
 
  <blockquote>
    <blockquote>
      <blockquote>
        <blockquote>
          <blockquote>
            <blockquote>
              <p>Powers of Election Commission (Article 118(4) and 126 of the Constitution, read with Article 4 of the Representation of the People Order, 1972): The Election Commission is an independent constitutional body in the exercise of its functions and subject only to the Constitution and any other law. The Commission may authorize its Chairman or any of its members or any of its officers to exercise and perform all or any of its powers and functions under the law. Article 126 of the Constitution and Articles 4 and 5 of the Representation of the People Order, 1972 provide that it shall be the duty of all executive authorities to assist the Election Commission in the discharge of its functions. The Commission has the power to require any person or authority to perform such functions or render such assistance for the purpose of election as it may direct.</p>
            </blockquote>
          </blockquote>
        </blockquote>
      </blockquote>
    </blockquote>
  </blockquote>
</article>

<footer>Copyright &copy; Sagor And Mahmudul</footer>

</div>

</body>
</html>
