<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
session_start();
$a='NOT';
$sql="UPDATE  voterinfo SET status='$a'";
$result=mysqli_query($db,$sql);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
<title>Untitled Document</title>
</head>

<body>
<h1 align="center" style="background-color:#00CCFF" style="border-bottom:hidden" style="width:100%">Election Commission Bangladesh</h1></td>
<div class="navbar">
 <a href="Sadminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="adminadd.php" style="text-decoration:none" style="display:block">Admin Add</a>
  <div class="dropdown">
    <button class="dropbtn">Add Candidate  
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="candidateadd.php" style="text-decoration:none" style="display:block">National election</a>
    <a href="cityelection.php" style="text-decoration:none" style="display:block">City election</a>
  </div>
</div>
<a href="teamadd.php" style="text-decoration:none" style="display:block">Add Party </a>

<div class="dropdown">
    <button class="dropbtn">National Election
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="overallresult.php" style="text-decoration:none" style="display:block">Over all result </a>
	<a href="Seatresult.php" style="text-decoration:none" style="display:block">Winner List </a>
	<a href="allinfo.php" style="text-decoration:none" style="display:block">Final Result</a>
  </div>
</div>

<div class="dropdown">
    <button class="dropbtn">City Corporation Result
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="cityresult.php" style="text-decoration:none" style="display:block">City Corporation Result</a>
	<a href="citywinerlist.php" style="text-decoration:none" style="display:block">Winner List </a>
  </div>
</div>
<a href="storeresult.php" style="text-decoration:none" style="display:block">Store Result</a>
<div class="dropdown">
    <button class="dropbtn">Election Update
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
   <a href="electionadd.php" style="text-decoration:none" style="display:block">Election Add</a>
	<a href="electiondlet.php" style="text-decoration:none" style="display:block">Election Delate</a>
  </div>
</div>
<a href="active.php" style="text-decoration:none" style="display:block">Active Election</a>
<a href="upload.php" style="text-decoration:none" style="display:block">Notice</a>
</div>


</body>
</html>