<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$nid=mysqli_real_escape_string($db,$_POST['Name1']);
$team=mysqli_real_escape_string($db,$_POST['Team1']);
$seat=mysqli_real_escape_string($db,$_POST['Seat1']);
$center=mysqli_real_escape_string($db,$_POST['cntr']);

$sql="SELECT * FROM city_candidateinfo WHERE Nid='$nid' and city='$seat'and Team='$team'";
$result=mysqli_query($db,$sql);
while($row=mysqli_fetch_array($result))
{
$VoteGet1= $row['Vote_Get'];
$Name=$row['Name'];
}
//echo $VoteGet1;
$VoteGet1=$VoteGet1+1;
$sql="UPDATE  city_candidateinfo SET Vote_Get='$VoteGet1' WHERE Nid='$nid' and city='$seat'and Team='$team'";
$result=mysqli_query($db,$sql);


header("location:councilor.php");

}
?>
