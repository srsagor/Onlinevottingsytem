<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
<title>Untitled Document</title>
</head>

<body>
<h1 align="center" style="background-color:#00CCFF" style="border-bottom:hidden" style="width:100%">Election Commission Bangladesh</h1></td>
<div class="navbar">
 <a href="Sadminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="adminadd.php" style="text-decoration:none" style="display:block">Admin Add</a>
  <div class="dropdown">
    <button class="dropbtn">Candidate Add 
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="candidateadd.php" style="text-decoration:none" style="display:block">National election</a>
    <a href="cityelection.php" style="text-decoration:none" style="display:block">City election</a>
  </div>
</div>
<a href="teamadd.php" style="text-decoration:none" style="display:block">Team add </a>

<div class="dropdown">
    <button class="dropbtn">National Election
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="overallresult.php" style="text-decoration:none" style="display:block">Over all result </a>
	<a href="Seatresult.php" style="text-decoration:none" style="display:block">Winner List </a>
	<a href="allinfo.php" style="text-decoration:none" style="display:block">Final Result</a>
  </div>
</div>

<div class="dropdown">
    <button class="dropbtn">City Corporation Result
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="cityresult.php" style="text-decoration:none" style="display:block">City Corporation Result</a>
	<a href="citywinerlist.php" style="text-decoration:none" style="display:block">Winner List </a>
  </div>
</div>
<a href="storeresult.php" style="text-decoration:none" style="display:block">Store Result</a>
<div class="dropdown">
    <button class="dropbtn">Election Update
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
   <a href="electionadd.php" style="text-decoration:none" style="display:block">Election Add</a>
	<a href="electiondlet.php" style="text-decoration:none" style="display:block">Election Delate</a>
  </div>
</div>
<a href="active.php" style="text-decoration:none" style="display:block">Active Election</a>
<a href="upload.php" style="text-decoration:none" style="display:block">Notice</a>
</div>


<form>
<label>National Election </label>
<input type="button"  Value="Store"  <?php include("config.php");$sql="SELECT * from level Where vote_type='nation' and (status='Stop' OR status='Running')";$result=mysqli_query($db,$sql);$row=mysqli_fetch_array($result,MYSQLI_ASSOC);$count=mysqli_num_rows($result);
if(count==1)
{
echo "disabled='disabled'";
}
?> />
</form>
</body>
</html>

<?php 
    include("config.php");
	
 	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo");
	$row = mysqli_fetch_array($result);
	$total_voter=$row['COUNT(*)'];
	//echo $total_voter;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='male'");
	$row = mysqli_fetch_array($result);
	$total_male_voter=$row['COUNT(*)'];
	//echo $total_male_voter;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='female'");
	$row = mysqli_fetch_array($result);
	$total_female_voter=$row['COUNT(*)'];
	//echo $total_female_voter;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where status='YES'");
	$row = mysqli_fetch_array($result);
	$total_votecast=$row['COUNT(*)'];
	//echo $total_votecast;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='male' and status='YES'");
	$row = mysqli_fetch_array($result);
	$total_male_votecast=$row['COUNT(*)'];
	//echo $total_male_votecast;
	
	$result = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo where Gender='female' and status='YES'");
	$row = mysqli_fetch_array($result);
	$total_female_votecast=$row['COUNT(*)'];
	//echo $total_female_votecast;
	
	
	$sql=mysqli_query($db,"INSERT INTO  summary (year,total_voter,total_male_voter,total_female_voter,total_vote_cast,total_male_voter_cast,total_female_voter_cast) VALUES('2018','$total_voter','$total_male_voter','$total_female_voter','$total_votecast','$total_male_votecast','$total_female_votecast')");
	
	
	
	
	
	
	$sql=mysqli_query($db,"SELECT *  FROM candidateinfo ");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $Nid=$row['Nid'];
		   $voteget=$row['VoteGet'];
		   $team=$row['Team'];
		   $seat=$row['Seat'];
		   //echo $Nid.$voteget.$team.$seat;
		   $result=mysqli_query($db,"INSERT INTO  yearhistory (year,Nid,vote_get,Team,Seat) VALUES('2018','$Nid','$voteget','$team','$seat')");
		   
		  }
		 
		 
		 
		 $sql=mysqli_query($db,"SELECT *  FROM winner_list  ");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $Nid=$row['Nid'];
		   $team=$row['Team'];
		   $seat=$row['Seat'];
		  // echo $Nid.$team.$seat;
		  $result=mysqli_query($db,"INSERT INTO  parliamentlist (year,Nid,Team,Seat) VALUES('2018','$Nid','$team','$seat')");
		   
		  }
		  
		  
		  $sql=mysqli_query($db,"SELECT *, COUNT(Name) AS seat FROM winner_list  GROUP BY Team");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $team=$row['Team'];
		   $seat=$row['seat'];
		    //echo $team.$seat;
			 $result=mysqli_query($db,"INSERT INTO  teamhistory (year,Total_voter,Team,Voteget,Seatget) VALUES('2019','$total_voter','$team','','$seat')");
		  }
		 
		  $sql=mysqli_query($db,"SELECT *, SUM(VoteGet) AS vote FROM candidateinfo  GROUP BY Team");
		  while($row = mysqli_fetch_array($sql))
		  {
		   $team=$row['Team'];
		   $Vote=$row['vote'];
		    echo $team.$Vote;
			$result=mysqli_query($db,"UPDATE teamhistory SET VoteGet='$Vote' WHERE year='2018' and Team='$team'");
		  }
?> 