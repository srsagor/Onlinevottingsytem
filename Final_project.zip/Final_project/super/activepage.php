<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','Voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE); 
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$a=mysqli_real_escape_string($db,$_POST['election']);
$c=mysqli_real_escape_string($db,$_POST['stu']);
if(strcasecmp( $c, 'Stop' ) == 0)
{
$sql="UPDATE  level SET status='Running' WHERE vote_type='$a' and status='$c'";
$result=mysqli_query($db,$sql);
$c='NOT';
$sql="UPDATE  voterinfo SET status='$c'";
$result=mysqli_query($db,$sql);
header("location:active.php");
}
if(strcasecmp( $c, 'Running' ) == 0)
{
$sql="UPDATE  level SET status='End' WHERE vote_type='$a' and status='$c'";
$result=mysqli_query($db,$sql);
header("location:active.php");
}
if(strcasecmp( $c, 'End' ) == 0)
{
$sql="UPDATE  level SET status='Stop' WHERE vote_type='$a' and  status='$c'";
$result=mysqli_query($db,$sql);
header("location:active.php");
}
}
?>
