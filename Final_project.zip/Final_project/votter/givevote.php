<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$nid=mysqli_real_escape_string($db,$_POST['Name1']);
$team=mysqli_real_escape_string($db,$_POST['Team1']);
$seat=mysqli_real_escape_string($db,$_POST['Seat1']);
$center=mysqli_real_escape_string($db,$_POST['cntr']);

$sql="SELECT * FROM candidateinfo WHERE Nid='$nid' and Seat='$seat'and Team='$team'";
$result=mysqli_query($db,$sql);
while($row=mysqli_fetch_array($result))
{
$VoteGet1= $row['VoteGet'];
$Name=$row['Name'];
}
//echo $VoteGet1;
$VoteGet1=$VoteGet1+1;
$sql="UPDATE  candidateinfo SET VoteGet='$VoteGet1' WHERE Nid='$nid' and Seat='$seat'and Team='$team'";
$result=mysqli_query($db,$sql);

$sql="INSERT INTO totalvote(Name,Nid,Team,Seat,Center) VALUES('$Name','$nid','$team','$seat','$center')";
if($db->query($sql)===TRUE)
{
header("location:loginvoter.php");
session_destroy() ;
}
else
{
echo "Error".$sql."<br>".$conn->error;
}
}
?>
