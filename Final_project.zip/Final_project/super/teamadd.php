<?php 
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$name=mysqli_real_escape_string($db,$_POST['name']);
$CM=mysqli_real_escape_string($db,$_POST['cm']);
$symbol=mysqli_real_escape_string($db,$_POST['symbol']);
$adress=mysqli_real_escape_string($db,$_POST['adress']);
          $destination = "TeamPhoto/".$_FILES['image']['name'];
         $filename    = $_FILES['image']['tmp_name']; 
		 move_uploaded_file($filename, $destination);
$sql="INSERT INTO team_name (Team_Name,Chirerperson,symbol,Adress,image) VALUES('$name','$CM','$symbol','$adress','$destination')";
if($db->query($sql)===TRUE)
{
header("location:sadminpage.php");
}
else
{
echo "Error".$sql."<br>".$conn->error;
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Party Registration</title>
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body bgcolor="#0066CC">
 <h1 style="border-bottom:hidden" style="width:100%"><img src="../image/pic.png"  width="101" height="69"/>Election Commission Bangladesh</h1>
<div class="navbar" align="center">
<a href="Sadminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="adminadd.php" style="text-decoration:none" style="display:block">Returning Officer Add</a>
   <a href="candidateadd.php" style="text-decoration:none" style="display:block">National election</a>
<a href="teamadd.php" style="text-decoration:none" style="display:block">Party Add </a>
<a href="overallresult.php" style="text-decoration:none" style="display:block">Overall Result </a>
	<a href="Seatresult.php" style="text-decoration:none" style="display:block">Winner List </a>
	<a href="allinfo.php" style="text-decoration:none" style="display:block">Final Result</a>
<div class="dropdown">
    <button class="dropbtn">Election Update
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
   <a href="electionadd.php" style="text-decoration:none" style="display:block">Election Add</a>
	<a href="electiondlet.php" style="text-decoration:none" style="display:block">Election Delete</a>
  </div>
</div>
<a href="active.php" style="text-decoration:none" style="display:block">Active Election</a>
<a href="upload.php" style="text-decoration:none" style="display:block">Notice</a>
</div>
<div id="body" style="display:block">
<div id="left"  style="background-color: #CCCCCC">
<?php
include("Config.php");
   session_start();
   $N=$_SESSION['myusername'];
   $sql="SELECT * FROM voterinfo WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
		
		date_default_timezone_set('Asia/Dhaka');
		echo "<font size='+1'>";
		echo date("l jS \ F Y ") . "<br>";
		echo "<font>";
		echo "<br>";
			$ad="../super/".$row['imagename'];
			echo "<img style='float:center; border-radius:200;width:190px;height:250px' src='".$ad."'>";
			echo "<br>";
			echo "<font size='+2'>" . $row['Name']."</font>";
			echo "<br>";
   $sql="SELECT * FROM sadmin WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
echo "<font size='+1'>" . $row['Post']."</font>";
echo "<br>";
echo "<font size='+2'>" ."J_Date:" . $row['Join_date'] ;
echo "<br>";
echo "R_Date:" . $row['r_date'] ;
echo "<br>";
}
}
?>
<a href="logout.php" style="text-decoration:none" style="display:block"><img src="../image/logout-button-png-hi.png" height="50" width="80" /></a>
</div>
<div id="right" style="background-color: #CCCCCC">
<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
    </MARQUEE><br />
		<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
        </MARQUEE>
</div>
<form method="post" enctype="multipart/form-data">
<table  align="center" style="width:69%">
<tr>
<th colspan="3" align="center"><h1>Party Registration </h1></th>
</tr>
<tr>
<td>Team Name:</td>
<td><input type="text" name="name" required/></td>
</tr>
<tr>
<td>Chirperson Name</td>
<td><input type="text" name="cm"required/></td>
</tr>
<tr>
<td><label>Symbol Name:</label></td>
<td><input type="text" name="symbol"required/></td>
</tr>
<tr>
<td><label>Adress:</label></td>
<td><input type="text" name="adress" required/>
</td>
</tr>
<tr>
<td><label>Image:</label></td>
<td colspan="4"><input type="file" value="" name="image" required/></td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="sumbit" class="button" /></td>
</tr>
</table>
</form>
</div>
</div>
</body>
</html>