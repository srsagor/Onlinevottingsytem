<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Notice </title>
<link rel="stylesheet" type="text/css" href="CSS/style.css">
</head>

<body bgcolor="#CCCCCC">
<h1 align="center"style="border-bottom:hidden">Election Commission Bangladesh</h1>

<div class="container">
<div class="navbar">
 <a href="index.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="super/superadmin_login.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp; Election Commissioner Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a  href="Admin/admin_login.php" style="text-decoration:none" style="display:block" >&nbsp;&nbsp;Returning Officer Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="last.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Show Projected Result</a>
   <a href="list.php" style="text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Election Commissioner list&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="notice.php" style="text-decoration:none"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Notice&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
</div>
<div id="body">
<div id="left">
<marquee behavior="scroll" direction="up">
    <img src="image/pic.png" width="120" height="80" alt="Natural" />
  </marquee>
</div>
<div id="right">
<marquee> ece hhsds dshdsd ksdjsd kjasasad </marquee>
</div>
<br />
<br />
<br />
<br />

<?php
include("Config.php");
   $sql="SELECT * FROM notice";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{

echo "<li>".$row['notice']."</li>";

echo "<br>";
}
?>
<img src="image/82_Sheik+Hasina_02102016_0002.jpg" align="right" height="40%" width="40%" />
</div>
    <h5 align="center"><footer> Copyright &copy; SrS</footer></h5>
  </div>
</body>
</html>
