<?php
include("config.php");
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>chack Voter</title>
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
</head>
<body style="background-color:#0066CC">
<h1 style="border-bottom:hidden" style="width:100%"><img src="../image/pic.png"  width="125" height="70"/>Election Commission Bangladesh</h1>
<div class="container">
<div class="navbar">
 <a href="adminpage.php" style="text-decoration:none" style="display:block">Home</a>
  <a href="regestion.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voter Registration&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <div class="dropdown">
    <button class="dropbtn">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;
      <i class="fa fa-caret-down"></i>
    </button>
  <div class="dropdown-content">
    <a href="entry.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Center Entry&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="update.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Update&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="delate.php">&nbsp;&nbsp;&nbsp;&nbsp;Center Delete&nbsp;&nbsp;&nbsp;&nbsp;</a>
  </div>
</div>
<a href="infochk.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Voter Information Change&nbsp;&nbsp;&nbsp;&nbsp;</a>

   <a href="resultCenter.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp; Cheak Center Result &nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="Acupdate.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;Account Update&nbsp;&nbsp;&nbsp;&nbsp; </a>
	<a href="logout.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;LogOut&nbsp;&nbsp;&nbsp;&nbsp; </a>
</div>
<div id="body">
<div id="left" style="background-color: #CCCCCC">
<?php
include("Config.php");
   session_start();
   $N=$_SESSION['myusername'];
   $sql="SELECT * FROM voterinfo WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
$ad= $row['imagename'];
echo "<img style='float:center;border:3px solid black;border-radius:20px;width:190px;height:250px' src='".$ad."'>";
echo "<br>";
echo "<br>";
echo "<font size='+2'>" . $row['Name'];
echo "<br>";

}
   $sql="SELECT * FROM admin WHERE Nid='$N'";
   $result = $db->query($sql);
   while($row = mysqli_fetch_array($result))
{
echo "Area:" . $row['Area'] ;
echo "<br>"."</font>";
echo "Post:" . $row['Post'] ;
echo "<br>";
echo "<font size='+2'>"."J_Date:" . $row['Join_date'] ;
echo "<br>";
echo "R_Date:" . $row['r_date'] ;
echo "<br>";
}
   ?>
</div>
<div id="right" style="background-color: #CCCCCC">
<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
      </MARQUEE><br />
		<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
		<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="../image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="../image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="../image/maxresdefault.jpg" width="200"/>
        </MARQUEE>
</div>
<form  method="post" align="center">
Information Update<br />
<label>Nid:</label>
<input type="text"   name="Nid" required /><br /><br />
<input type="submit"  value="Search" class="button"/>
</form>
<?php
include("config.php");
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST")
{
      $myusername = mysqli_real_escape_string($db,$_POST['Nid']); 
           //echo "<form align='center' >";  
				        
				
			 $sql = "SELECT * FROM voterinfo WHERE Nid ='$myusername'";
			  $result2 = $db->query($sql);
		   while($row = mysqli_fetch_array($result2))
		{
		 echo $row['Name'];
		echo '<form method="post" align="center" action="infochng.php">
		   <label>Name:</label>
			<input type="text" name="Name1"  value='.$row['Name'].'>
			<label>NID:</label>
			<input type="text" name="Team1" disabled="disabled" value='.$row['Nid'].'></br></br>
			<label>Date Of Birth:</label>
			<input type="date" disabled="disabled" name="Seat1" value='.$row['Dob'].'>
			<label>Present:</label>
			<input type="text" name="Ctype" value='.$row['Present'].'></br></br>
			<label>Permanent:</label>
			<input type="text" name="Name1" value='.$row['Permanent'].'>
			<label>Division:</label>
			<input type="text" name="Team1" value='.$row['Division'].'></br></br>
			<label>District:</label>
			<input type="text" name="Seat1" value='.$row['District'].'>
			<label>Thana:</label>
			<input type="text" name="Ctype" value='.$row['Thana'].'></br></br>
			<label>Religion:</label>
			<input type="text" disabled="disabled" name="Name1" value='.$row['Religion'].'>
			<label>Gender:</label>
			<input type="text" disabled="disabled" name="Team1" value='.$row['Gender'].'></br></br>
			<label>Father:</label>
			<input type="text" disabled="disabled" name="Seat1" value='.$row['Father'].'>
			<label>Mother:</label>
			<input type="text"  disabled="disabled" name="Ctype" value='.$row['Mother'].'></br></br>
			<label>Seat:</label>
			<input type="text" name="Seat1" value='.$row['Seat'].'>
			<label>Center:</label>
			<input type="text" name="Ctype" value='.$row['Center'].'></br></br>
			<td><input type="submit" name="vote" Value="Vote"></td>';
             echo "</form>";
		
		}
		//$sql = "UPDATE  voter_login SET status='VIEW' WHERE Nid ='$myusername'";
		//result1=mysqli_query($db,$sql);
		}
?>
</div>
</div>
</body>
</html>