<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>compare result</title>
<link rel="stylesheet" type="text/css" href="CSS/style.css">

</head>

<body style="background-color:#0066CC">
<h1 align="center"style="border-bottom:hidden" style="width:100%"><img src="image/pic.png"  width="110" height="71"/>Election Commission Bangladesh</h1>


<div class="navbar">
<a href="index.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="super/superadmin_login.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp; Election Commissioner Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a  href="Admin/admin_login.php" style="text-decoration:none" style="display:block" >&nbsp;&nbsp;Returning Officer Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="last.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Show Projected Result</a>
   <a href="list.php" style="text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Election Commissioner list&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="notice.php" style="text-decoration:none"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Notice&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
</div>
<form align="center" method="post">
<label><font size="+2" >Select Any Year to see result</label>

<select name="year" required>
<optgroup>
<option value="1973">1973</option>
<option value="1979">1979</option>
<option value="1986">1986</option>
<option value="1988">1988</option>
<option value="1991">1991</option>
<option value="1996">1996</option>
<option value="2001">2001</option>
<option value="2008">2008</option>
<option value="2014">2014</option>
</optgroup>
</select>
<br />
<br />
<input type="submit" class="btn btn-primary btn-lg" value="Show">
</form>
<br />
<br />
<div id="donutchart" style="width: 100%; height: 400px;"></div>
<?php
define('DB_SERVER','localhost');
		define('DB_USERNAME','root');
		define('DB_PASSWORD','');
		define('DB_DATABASE','voting');
		$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
		if($_SERVER["REQUEST_METHOD"]=="POST")
{
 $year = mysqli_real_escape_string($db,$_POST['year']);
 echo "<h1>Full Summary Of Election:</h1>";
   $sql=mysqli_query($db,"SELECT *  FROM summary WHERE year='$year'");
   echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Year";echo"</td>"; 
echo "<th>"; echo "Total Voter";echo"</td>";
echo "<th>"; echo "Total Male Voter";echo"</td>";
echo "<th>"; echo "Total Female Voter";echo"</td>";
echo "<th>"; echo "Total Vote Cast";echo"</td>";
echo "<th>"; echo "Total Male Vote Cast";echo"</td>";
echo "<th>"; echo "Total Female Vote Cast";echo"</td>";
echo "<th>"; echo "Invalid Vote";echo"</td>";
echo "<th>"; echo "Percentage Vote Cast";echo"</td>";
echo "</tr>";
		  while($row = mysqli_fetch_array($sql))

			{
				echo "<tr>";
                 echo "<td>".$row['year']."</td>"; 
				 echo "<td>".$row['total_voter']."</td>"; 
				 $tv=$row['total_voter'];
				 echo "<td>".$row['total_male_voter']."</td>"; 
				 echo "<td>".$row['total_female_voter']."</td>"; 
				 echo "<td>".$row['total_vote_cast']."</td>";
				 $tvc=$row['total_vote_cast']; 
				 echo "<td>".$row['total_male_voter_cast']."</td>"; 
				 echo "<td>".$row['total_female_voter_cast']."</td>";
				 echo "<td>".$row['Invalid_casting']."</td>"; 
				 $p=($tvc/$tv)*100;
				 echo "<td>".number_format((float)$p, 2, '.', '')."</td>";
				 //echo "<td>".$p."</td>";
				 echo "</tr>";
			}
			echo "</table>";
			
     echo "<h1>All Party History:</h1>";

$sql=mysqli_query($db,"SELECT *  FROM teamhistory WHERE year='$year' ");
   echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Year";echo"</td>"; 
echo "<th>"; echo "Party Name";echo"</td>";
echo "<th>"; echo "Total Vote Get";echo"</td>";
echo "<th>"; echo "Total Seat Get";echo"</td>";
echo "<th>"; echo "Percentage Vote Cast";echo"</td>";
echo "</tr>";
		  while($row = mysqli_fetch_array($sql))

			{
				echo "<tr>";
                 echo "<td>".$row['year']."</td>"; 
				 echo "<td>".$row['Team']."</td>"; 
				 $tv=$row['Total_voter'];
				 echo "<td>".$row['VoteGet']."</td>"; 
				 echo "<td>".$row['Seatget']."</td>"; 
				 $tvc=$row['VoteGet']; 
				 $p=($tvc/$tv)*100;
				 echo "<td>".number_format((float)$p, 2, '.', '')."</td>";
				 echo "</tr>";
			}
			echo "</table>";

echo "<h1>All Winner List:</h1>";
$sql=mysqli_query($db,"SELECT *  FROM parliamentlist WHERE year='$year' ");
   echo "<table border='1'width='100%'>";
echo "<tr>";
echo "<th>"; echo "Year";echo"</td>"; 
echo "<th>"; echo "Name";echo"</td>";
echo "<th>"; echo "Party";echo"</td>";
echo "<th>"; echo "Seat";echo"</td>";
echo "</tr>";
		  while($row = mysqli_fetch_array($sql))

			{
				echo "<tr>";
                 echo "<td>".$row['year']."</td>"; 
				 echo "<td>".$row['Name']."</td>"; 
				 echo "<td>".$row['Team']."</td>"; 
				 echo "<td>".$row['Seat']."</td>"; 
				 echo "</tr>";
			}
			echo "</table>";
			
			
$sql="SELECT * FROM teamhistory WHERE year='$year'";
$result=mysqli_query($db,$sql);
}
?>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Team', 'VoteGet'],
		  <?php
          while($row=mysqli_fetch_array($result))
			{
			echo "['".$row['Team']."',".$row['VoteGet']."],";
			$sum=$sum+$row['VoteGet'];
			$voter=$row['Total_voter'];
			} 
			
			$not=$voter-$sum;
				echo "['Not Vote',".$not."],";
			
			?>
        ]);
        var options = {
          title: 'Vote  Percentage',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>
  
    

</body>
</html>
