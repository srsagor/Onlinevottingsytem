<?php
define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','voting');
$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
$sql="SELECT * FROM  `team_name` ";
$result=mysqli_query($db,$sql);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Result Prediction</title>
<link rel="stylesheet" type="text/css" href="CSS/style.css">
</head>

<body style="background-color:#0066CC">
<h1 style="border-bottom:hidden" style="width:100%"><img src="image/pic.png"  width="101" height="69"/>Election Commission Bangladesh</h1>

<div class="container">
<div class="navbar">
 <a href="index.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="super/superadmin_login.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp; Election Commissioner Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a  href="Admin/admin_login.php" style="text-decoration:none" style="display:block" >&nbsp;&nbsp;Returning Officer Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
    <a href="last.php" style="text-decoration:none" style="display:block">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Show Projected Result</a>
   <a href="list.php" style="text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Election Commissioner list&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="notice.php" style="text-decoration:none"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Notice&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
</div>
<div id="body">
<div id="left">
<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/maxresdefault.jpg" width="200"/>
      </MARQUEE><br />
		<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
		<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/maxresdefault.jpg" width="200"/>
        </MARQUEE>
</div>
<div id="right" >
<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/maxresdefault.jpg" width="200"/>
      </MARQUEE><br />
		<MARQUEE behavior="scroll" direction="up" width="200" height="100" alt="Natural">
		<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
       <img src="image/pic.png" width="200" />
	   <h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
<img src="image/82_Sheik+Hasina_02102016_0002.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/images.jpg"width="200"  />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/download.jpg" width="200" />
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/Smart-Card-1.jpg" width="200"/>
	<h6>&nbsp;&nbsp;&nbsp;&nbsp</h6>
	<img src="image/maxresdefault.jpg" width="200"/>
        </MARQUEE>
</div>
<br />
<br />
<br />
<form method="post">
<table align="center">
<tr>
<th><font size="+2">Select Party Name:</th>
<th>
<select name="team" required>
<option >--------------------</option>
<?php while($row= mysqli_fetch_array($result)):;?>
<option value="<?php echo $row[0];?>"><?php echo $row[0];?></option>
<?php endwhile;?>
</select>
</th>
</tr>
<tr>
<td></td>
<td><input type="submit" value="Show" class="button" /></td>
</tr>

</table>
<p>
  <?php
include("config.php");
function linear_regression($x, $y,$z) {

   $n = count($x);
  // ensure both arrays of points are the same size
  if ($n != count($y)) {

    trigger_error("linear_regression(): Number of elements in coordinate arrays do not match.", E_USER_ERROR);
  
  }

  // calculate sums
  $x_sum = array_sum($x);
  $y_sum = array_sum($y);
  $xx_sum = 0;
  $xy_sum = 0;
  
  for($i = 0; $i < $n; $i++) {
  
    $xy_sum+=($x[$i]*$y[$i]);
    $xx_sum+=($x[$i]*$x[$i]);
    
  }
  
  // calculate slope
  $m = (($n * $xy_sum) - ($x_sum * $y_sum)) / (($n * $xx_sum) - ($x_sum * $x_sum));
  
  // calculate intercept
  $b = ($y_sum - ($m * $x_sum)) / $n;
    
  // return result
  //return array("m"=>$m, "b"=>$b);
		 define('DB_SERVER','localhost');
		define('DB_USERNAME','root');
		define('DB_PASSWORD','');
		define('DB_DATABASE','voting');
		$db=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
    $result1 = mysqli_query($db,"SELECT COUNT(*) FROM voterinfo");
	$row = mysqli_fetch_array($result1);
	//$total_voter=$row['COUNT(*)'];
	$total_voter=74951319;
    $sum=$m*$total_voter;
	echo "<b>Total Voter Is:</b>".$total_voter;
	echo"</br>";
    $y=$b+$sum;
	if($y<0)
	{
	echo "<b>Possibility Of Vote Getting  </b>".$z.":".round($sum);
	$pr=(round($sum)/$total_voter)*100;
	echo "</br>";
	echo "<b>Percentage Of Vote getting Is: </b>" ;echo "<td>".number_format((float)$pr, 2, '.', '')."</td>";
	}
	else if($y>$total_voter)
	{
	echo "<b>Possibility Of Vote Getting </b> ".$z.":".round($sum);
	$pr=(round($sum)/$total_voter)*100;
	echo "</br>";
	echo "<b>Percentage Of Vote getting Is: </b>" ;echo "<td>".number_format((float)$pr, 2, '.', '')."</td>";
	

	}
	else if($y>0 or $y<=$total_voter)
	{
    echo "<b>Possibility Of Vote Getting  </b>".$z.":".round($y);
	$pr=(round($sum)/$total_voter)*100;
	echo "</br>";
	echo "<b>Percentage Of Vote getting Is: </b>" ;echo "<td>".number_format((float)$pr, 2, '.', '')."</td>";
	}
	
  
  

}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
 $Team = mysqli_real_escape_string($db,$_POST['team']);
 echo "<table border='1'width='69%'>";
echo "<tr>";
echo "<th>"; echo "Year";echo"</td>"; 
echo "<th>"; echo "Total Voter";echo"</td>";
echo "<th>"; echo "Total Vote Got";echo"</td>";
echo "<th>"; echo "Percentage";echo"</td>";
echo "</tr>";
   $sql=mysqli_query($db,"SELECT *  FROM teamhistory WHERE Team='$Team'");
		  while($row = mysqli_fetch_array($sql))

			{
				$array[] = $row['Total_voter'];	
				$array1[] = $row['VoteGet'];
			echo "<tr>";
                 echo "<td>".$row['year']."</td>"; 
				 echo "<td>".$row['Total_voter']."</td>"; 
				 echo "<td>".$row['VoteGet']."</td>";
				 $a = $row['Total_voter'];	
				 $b = $row['VoteGet']; 
				 if($a>0)
				 {
				 $p=($b/$a)*100;
				 }
				 else
				 {
				 $p=0;
				 }
				 echo "<td>".number_format((float)$p, 2, '.', '')."</td>"; 
				 echo "</tr>";
			}
			echo "</table>";
linear_regression($array, $array1,$Team);
}

?>
</div>
    <h5 align="center"><footer> Copyright &copy; SrS</footer></h5>
  </div>
</body>
</html>